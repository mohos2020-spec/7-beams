import { Shield, Zap, Globe } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function DashboardPage() {
  const domains = [
    {
      id: 1,
      name: "SITE 1",
      icon: Shield,
      sites: "#1 Sites",
      description: "Redirects to Discord OAuth for authentication.",
      url: "https://shockify.st/?code=MDU5NzIzODE3NDU4MDk2ODU0XzQ3NTIyNTAxNzE2NzUxNDU4MDlfODk1NDIwMDE5NjgxMjkyNzE5Nw==",
    },
    {
      id: 2,
      name: "SITE 2",
      icon: Zap,
      sites: "#2 Sites",
      description: "Redirects to homepage.",
      url: "https://www.logged.tg/auth/7beams",
    },
    {
      id: 3,
      name: "SITE 3",
      icon: Globe,
      sites: "#3 Sites",
      description: "Shows a collection of Roblox sites with dashboard functionality",
      url: "https://roblox.com", // Replace with your actual URL
    },
  ]

  return (
    <main className="min-h-screen bg-white py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold text-black mb-2 tracking-tight">7 BEAMS</h1>
          <div className="w-24 h-1 bg-black mx-auto mb-4" />
          <p className="text-lg text-gray-600">Domain Management System</p>
        </div>

        {/* Domain Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          {domains.map((domain) => {
            const Icon = domain.icon
            return (
              <div
                key={domain.id}
                className="bg-white border-4 border-black rounded-2xl p-6 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] hover:shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] transition-shadow"
              >
                <div className="flex items-start justify-between mb-6">
                  <div className="w-12 h-12 bg-black rounded-full flex items-center justify-center">
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex items-center gap-2 bg-black text-white px-3 py-1 rounded-full text-sm font-semibold">
                    <div className="w-2 h-2 bg-green-500 rounded-full" />
                    ACTIVE
                  </div>
                </div>

                <div className="mb-6">
                  <h2 className="text-2xl font-bold text-black mb-1">{domain.name}</h2>
                  <p className="text-gray-500 text-sm">{domain.sites}</p>
                </div>

                <Button
                  className="w-full bg-black text-white hover:bg-gray-800 rounded-xl py-6 text-base font-semibold"
                  asChild
                >
                  <a href={domain.url} target="_blank" rel="noopener noreferrer">
                    <span className="mr-2">↗</span>
                    Use Site
                  </a>
                </Button>
              </div>
            )
          })}
        </div>

        {/* Domain Information */}
        <div className="bg-white border-4 border-black rounded-2xl p-8 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-black mb-2">Domain Information</h2>
            <p className="text-gray-600">Use the domains above to access different services</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {domains.map((domain) => {
              const Icon = domain.icon
              return (
                <div key={domain.id} className="text-center">
                  <div className="w-16 h-16 bg-black rounded-full flex items-center justify-center mx-auto mb-4">
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-black mb-2">{domain.name}</h3>
                  <p className="text-gray-600 text-sm leading-relaxed">{domain.description}</p>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </main>
  )
}
